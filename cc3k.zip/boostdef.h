#ifndef BOOSTDEF_H
#define BOOSTDEF_H
#include "potion.h"

class BoostDef :public Potion {
    public:
    BoostDef(Player *player);
};

#endif
