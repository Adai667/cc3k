#ifndef WOUNDDEF_H
#define WOUNDDEF_H
#include "potion.h"

class WoundDef :public Potion {
    public:
    WoundDef(Player *player);
};

#endif
