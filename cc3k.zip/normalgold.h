#ifndef NORMALGOLD_H
#define NORMALGOLD_H
#include "gold.h"

class NormalGold :public Gold {
    public:
    NormalGold(Player *player);
};

#endif
