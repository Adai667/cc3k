#ifndef SMALLGOLD_H
#define SMALLGOLD_H
#include "gold.h"

class SmallGold :public Gold {
    public:
    SmallGold(Player *player);
};

#endif
