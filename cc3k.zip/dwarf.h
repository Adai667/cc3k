#ifndef DWARF_H
#define DWARF_H
#include<string>
#include "enemy.h"
using namespace std;
class Dwarf : public Enemy{
    public:
       Dwarf();
};


#endif
