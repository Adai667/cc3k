#ifndef BOOSTATK_H
#define BOOSTATK_H
#include "potion.h"

class BoostAtk :public Potion {
    public:
    BoostAtk(Player *player);
};

#endif
