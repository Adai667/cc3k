#include "boostatk.h"

BoostAtk::BoostAtk(Player *player)
    : Potion{ "BA", player, "Potion effect: increase Atk by 5", 5 } {}
