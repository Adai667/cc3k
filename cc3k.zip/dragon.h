#ifndef DRAGON_H
#define DRAGON_H
#include<string>
#include "enemy.h"
using namespace std;
class Dragon :public Enemy{
    public:
       Dragon();
   
};


#endif
