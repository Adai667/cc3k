#ifndef HALFLING_H
#define HALFLING_H
#include<string>
#include "enemy.h"
using namespace std;
class Halfling :public Enemy{
    public:
       Halfling();
};


#endif
