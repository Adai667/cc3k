#ifndef WOUNDATK_H
#define WOUNDATK_H
#include "potion.h"

class WoundAtk :public Potion {
    public:
    WoundAtk(Player *player);
};

#endif
