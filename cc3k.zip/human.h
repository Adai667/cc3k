#ifndef HUMAN_H
#define HUMAN_H
#include<string>
#include "enemy.h"
using namespace std;
class Human :public Enemy{
    public:
       Human();
};


#endif
