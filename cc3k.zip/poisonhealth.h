#ifndef POISONHEALTH_H
#define POISONHEALTH_H
#include "potion.h"

class PoisonHealth :public Potion {
    public:
    PoisonHealth(Player *player);
};

#endif
