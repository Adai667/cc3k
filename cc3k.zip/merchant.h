#ifndef MERCHANT_H
#define MERCHANT_H
#include<string>
#include "enemy.h"
using namespace std;
class Merchant :public Enemy{
    public:
       Merchant();
};


#endif
