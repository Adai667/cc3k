#include "boostdef.h"

BoostDef::BoostDef(Player *player)
    : Potion{ "BD", player, "Potion effect: increase Def by 5", 5 } {}
